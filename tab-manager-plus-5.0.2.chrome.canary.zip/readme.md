# Tab Manager Plus 5.0.2
This is an extended version of the old Tab Manager Google Chrome extension. Should work on both Chrome and Firefox. Malware free, with a new view type and many new features.

For a list of changes check out the [changelog](./CHANGELOG.md).

Please enjoy.

You can find and install this extension at the [Chrome Web Store](https://chrome.google.com/webstore/detail/cnkdjjdmfiffagllbiiilooaoofcoeff) or the [Firefox Add-Ons](https://addons.mozilla.org/en-US/firefox/addon/tab-manager-plus-for-firefox/).

If you love it, please [donate to support this extension](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=67TZLSEGYQFFW). Thank you <3

### license
MPLv2
